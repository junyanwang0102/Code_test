package rockets.model;

import static org.junit.jupiter.api.Assertions.*;

class LaunchUnitTest {
}